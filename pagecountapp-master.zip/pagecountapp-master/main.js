var http = require("http");
var redis = require("redis");
var argv = require("minimist")(process.argv.slice(2))
var express = require("express");
var bunyan = require("bunyan");
var os = require("os");

var app = express();
var monitorApp = express();

var log = bunyan.createLogger({name: "myapp",
                              level: "debug",
                              serializers:{
                                    err: bunyan.stdSerializers.err,
                                    req: bunyan.stdSerializers.req,
                                    res: bunyan.stdSerializers.res
                                  }
                              });

var port = argv['port'] || argv['p'];
var redisHost = argv['redis-host'] || argv['R'];
var redisPort = argv['redis-port'] || argv['P'];
var key = os.hostname();
log.debug({port: port, redisPort: redisPort, redisHost: redisHost, key: key});

var redisClient = redis.createClient(redisPort, redisHost);

redisClient.on("error", function (err) {
    log.info(err);
})

var requestId = 0;
function uuid () {
    return requestId++;

}

// Create function to get CPU information
function cpuTicksAcrossCores()
{
  //Initialise sum of idle and time of cores and fetch CPU info
  var totalIdle = 0, totalTick = 0;
  var cpus = os.cpus();

  //Loop through CPU cores
  for(var i = 0, len = cpus.length; i < len; i++)
  {
        //Select CPU core
        var cpu = cpus[i];
        //Total up the time in the cores tick
        for(type in cpu.times)
        {
            totalTick += cpu.times[type];
        }
        //Total up the idle time of the core
        totalIdle += cpu.times.idle;
  }

  //Return the average Idle and Tick times
  return {idle: totalIdle / cpus.length,  total: totalTick / cpus.length};
}

var startMeasure = cpuTicksAcrossCores();

function cpuAverage()
{
    var endMeasure = cpuTicksAcrossCores();

    //Calculate the difference in idle and total time between the measures
    var idleDifference = endMeasure.idle - startMeasure.idle;
    var totalDifference = endMeasure.total - startMeasure.total;

    //Calculate the average percentage CPU usage
    // return 0;
  return ((totalDifference - idleDifference)/totalDifference )*100;
}

function memoryLoad()
{
  totalMemory = os.totalmem()
  freeMemory = os.freemem()

  return ((totalMemory-freeMemory)/totalMemory)*100;
}


app.use(function (req, res, next) {
    req.log = log.child({req_id: uuid()});
    req.log.debug(key);
    redisClient.get(key, function (err, value) {
        if(err){
            req.log.info({err: err});
            redisClient.set(key, "1");
        } else{
            req.log.debug({key: value});
            redisClient.incr(key, function (err, value) {
                if(err){
                    req.log({err: err});
                }
            });
        }
    })
    next();
});

app.get("/", function (req, res) {
    res.end();
});

app.get("/count", function (req, res) {
    res.statusCode = 200;
    redisClient.get(key, function (err, value) {
        if(err)
            req.log.info({err: err});
        log.debug({key: value});
        obj = {};
        obj[key] = value;
        res.json(obj);
        res.end();
    });
});

var server = app.listen(port, function () {
    var host = server.address().address;
    var port = server.address().port;
    // console.log("server running on " + host + ":" + port);
    log.info("server running on " + host + ":" + port);
});

var monitorPort = 9090;

monitorApp.get("/metrics", function (req, res) {
    res.statusCode = 200;
    var obj = {cpu_average: cpuAverage(), memory_load: memoryLoad()};
    log.info(obj);
    res.json(obj);
    res.end();
})

var monitorServer = monitorApp.listen(monitorPort, function () {
    var host = monitorServer.address().address;
    var port = monitorServer.address().port;
    log.info("server running on " + host + ":" + port);

});
