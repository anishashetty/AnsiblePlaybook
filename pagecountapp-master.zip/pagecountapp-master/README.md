# Page Counter App

A very simple redis-backed site visit counter app written in node.js using express.
